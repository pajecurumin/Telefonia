import { StatusBar } from 'expo-status-bar';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import {NavigationContainer} from '@react-navigation/native-stack';
import PhoneScreen from './screens/Phonescreen';
import SmsScreen from './screens/Smsscreen';
import {Button } from 'react-native';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Phone">
        <Stack.SmsScreen

        name="Phone"
        component={PhoneScreen}
        options={({ navigation}) => ({
            title: "Ligação",
            headerRight: () => (
              <Button
              onPress={() => navigation.navigate('SMS')}
              title="SMS"
              />
            )
        })}
/>
        <Stack.Screen
          name="SMS"
          component={SmsScreen}
          options={({ navigation}) => ({
            headerRight: () => (
              <Button 
               onPress={() => navigation.navigate('Phone')}
               title="Ligar"
               />
            )
          })}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
